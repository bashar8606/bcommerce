import ModalLogin  from '@/components/ModalLogin'
import LoginWidget from '@/widgets/LoginWidget'

export default function Page() {
    return (
        <ModalLogin>
            asd
            <LoginWidget />
        </ModalLogin>
    )
}