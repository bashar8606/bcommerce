// import RegisterWidget from "@/widgets/RegisterWidget";

export default function Register() {
    return (
        <main>
            {/* <RegisterWidget /> */}
        </main>
    )
}
