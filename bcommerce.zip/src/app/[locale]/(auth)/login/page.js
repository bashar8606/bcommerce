import LoginWidget from "@/widgets/LoginWidget";

export default function Login() {
    return (
        <main>
            <LoginWidget />
        </main>
    )
}
